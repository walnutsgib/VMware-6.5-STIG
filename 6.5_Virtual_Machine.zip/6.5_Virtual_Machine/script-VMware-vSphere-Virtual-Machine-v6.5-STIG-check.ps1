Write-Host "This was written by Glen W. Chin with inputs from Robert B. Harris"
Write-Host "This program checks the VMware vSphere 6.5 Virtual Machine STIG: Version 1, Release 1 May 20, 2019" -ForegroundColor Green


## Check for PowerCLI modules being loaded and if it is not loaded then exit program ##
Try
{
	$PowerCLIVersion = (Get-PowerCLIVersion -ErrorAction Stop)
    Write-Host "You are running $PowerCLIVersion"
}
Catch
{
	Write-Host "You must use PowerCLI to run this script." -ForegroundColor Red
	Exit
}


## Get Input information (vCenter server name and VM machine names to test) ##
$InputConfigFile = Get-Content .\Input_Output\1.InputConfigFile.txt
$VIServer = $InputConfigFile[1]
$MachineNames = $InputConfigFile[3..($InputConfigFile.count)]
$VMSTIGChecks = Import-Csv ".\Input_Output\2.Input_STIG_6_5_Setting.csv" -Delimiter ',' 

#$NumberOfMachines = $InputConfigFile.count - 3
#Write-Host $NumberOfMachines

## Connect to vCenter  - does not run command to connect to vCenter if already connected to vCenter ##
If ($global:DefaultVIServer.IsConnected -eq $true)
{
    $vcenter=$global:DefaultVIServers.Name
    Write-Host "Already Connected to vCenter Server $vcenter"
}
Else   
{    
    Try
    {
	    Write-Host "Attempting to connect to vCenter Server: $VIServer"
	    Connect-VIServer -Server $VIServer -ErrorAction Stop
	    Write-Host "Connection to vCenter Server: $VIServer appears to be successful" -ForegroundColor Green
    }
    Catch 
    {
	    Write-Host "Could not connect to $VIServer...please recheck your credentials and vCenter server name"  -ForegroundColor Red
	    Write-Host $_  -ForegroundColor Red
        Exit
    }
}  



## Read input list of Virtual Machines and separate invalid/valid Virtual Machine names ##
#$invalidmachineserrors = @()
$InvalidMachines = @()
$ValidMachines = @()
$AllMachines = Get-VM * | select Name,PowerState

ForEach ($MachineName in $MachineNames)
{
    Try
	{
     $TempMachine = Get-VM $MachineName -ErrorAction stop
     Write-Host "$MachineName :valid machine name" -ForegroundColor Green
     $TempMachineVersion = $MachineName + " VM version: " + $TempMachine.extensiondata.config.version
     $ValidMachines += $MachineName
     $ValidMachinesPlusVersion += $TempMachineVersion
    }
    Catch
    {
     $InvalidMachines += $MachineName
     Write-Host "$MachineName :invalid machine name" -ForegroundColor Red
    }
}
$ValidMachinesPlusVersion | out-file "input_output\3.Output_Valid_System_Names_$VIServer.txt"
$InvalidMachines | out-file "input_output\4.Output_Invalid_System_Names_$VIServer.txt"
$AllMachines | Export-Csv -NoTypeInformation -force "input_output\5.Output_All_System_Names_$VIServer.csv"

##  Exits program if no valid systems are entered  ##
If ($ValidMachines.count -eq "0")
{
    Write-Host "No valid machine names to check. Please ensure the correct machines names are in the input file." -ForegroundColor Red
    Exit
}

## Get Date ##
$Now=Get-Date -Format "yyyy.MM.dd.HH.mm"



#Write-Host $VMSTIGChecks
$csvfileBIG = @()

ForEach ($CurrentVM in $ValidMachines)
{
        ## Collect Virtual Machines configuration in variable for processing
        $vm = Get-VM $CurrentVM

		ForEach($CurrentCheck in $VMSTIGChecks)
		{
			
			$Row = "" | select VM_Hostname,VulnID,STIGID,RuleTitle,Severity,Required_Hardening_Setting_Name,Required_Hardened_Value,Current_Value,Correctly_Set,Notes	

            #VulnID,Severity,STIGID,RuleTitle,SettingType,AdvancedSettingData,RequiredHardenedValue,InOriginalScript,Scriptable
            $VulnID = "$CurrentCheck.Vuln ID"
            $Severity = $CurrentCheck.Severity
            $STIGID = $CurrentCheck.STIGID			
			$RuleTitle = $CurrentCheck.RuleTitle
            $SettingType = $CurrentCheck.SettingType
            $RequiredHardeningSettingName = $CurrentCheck.AdvancedSettingData
			$RequiredHardenedValue = $CurrentCheck.RequiredHardenedValue
            $Notes = $CurrentCheck.Notes
            $CorrectlySet = "NR(Not Reviewed - Check Results and Notes Column)"
            
            
			
            If ($SettingType -eq "AdvancedSettingType")
            {
                $CurrentSetting = $VM|Get-AdvancedSetting -Name $RequiredHardeningSettingName
		        $CurrentValue = $CurrentSetting.Value
                If ($CurrentValue -eq $RequiredHardenedValue)
                {
                    $CorrectlySet= "Not A Finding"
                }
                Else
                {
                    $CorrectlySet = "Open"
                }
            }
            If ($SettingType -eq "Custom")
            {
                 If ($VulnID -eq "V-94575")
                 {
                    $CurrentSetting = ($vm | Get-HardDisk | Select Parent, Name, DiskType, Persistence | out-string).trim()
                    #$Currenttest1 = $CurrentSetting.extensiondata.config.hardware.device.deviceinfo.label|Select-String "USB"
                    $CurrentValue=$CurrentSetting
                 }
                 If ($VulnID -eq "V-94613")
                 {
                    $CurrentSetting = ($vm | Get-FloppyDrive | Select Parent, Name, ConnectionState)
                    $CurrentValue=$CurrentSetting
                    If (!$currentvalue)
                    {
                        $CorrectlySet= "Not A Finding"
                        $Notes = "No Floppy Drives Found" 
                    }
                 }
                 If ($VulnID -eq "V-94615")    
                 { 
                     $CurrentSetting = ($vm | Get-CDDrive | Select Parent,Name, ConnectionState)
                     $CurrentValue=$CurrentSetting
                     If (!$currentvalue)
                     {
                        $CorrectlySet= "Not A Finding"
                        $Notes = "No CD/DVD Drives Found" 
                     }
                 }
                 If ($VulnID -eq "V-94617")
                 {
                    $CurrentSetting = ($vm |Where {$_.ExtensionData.Config.Hardware.Device.DeviceInfo.Label -match "parallel"})
                    $CurrentValue = $CurrentSetting.extensiondata.config.hardware.device.deviceinfo.label|Select-String "parallel"
                    If (!$currentvalue)
                    {
                        $CorrectlySet= "Not A Finding"
                        $Notes = "No parallel devices found" 
                    }
                 }
                 If ($VulnID -eq "V-94619")
                 {
                    $CurrentSetting = ($vm |Where {$_.ExtensionData.Config.Hardware.Device.DeviceInfo.Label -match "serial"})
                    $CurrentValue = $CurrentSetting.extensiondata.config.hardware.device.deviceinfo.label|Select-String "serial"
                    If (!$currentvalue)
                    {
                        $CorrectlySet= "Not A Finding"
                        $Notes = "No serial devices found" 
                    }
                 }
                 If ($VulnID -eq "V-94621")
                 {
                    $CurrentSetting = $vm | Where {$_.ExtensionData.Config.Hardware.Device.DeviceInfo.Label -match "usb"}
                    $CurrentTemp = $CurrentSetting.extensiondata.config.hardware.device.deviceinfo.label|Select-String "USB"
                    $CurrentSetting2 = ($vm |Get-UsbDevice)
                    $CurrentSetting2 += $CurrentTemp
                    $CurrentValue =  $CurrentSetting2
                    If (!$currentValue)
                    {
                        $CorrectlySet= "Not A Finding"
                        $Notes = "No USB devices found" 
                    }
                 }
                 If ($VulnID -eq "V-94633")
                 {
                    $CurrentSetting = $vm | Get-AdvancedSetting -Name sched.mem.pshare.salt
                    $CurrentValue=$CurrentSetting.value
                    If (!$currentvalue)
                    {
                        $CorrectlySet= "Not A Finding"
                        $Notes = "No Shared Salt values found" 
                    }
                 }
                 If ($VulnID -eq "V-94635")
                 {
                    $CurrentSetting = $vm | Get-AdvancedSetting -Name "ethernet*.filter*.name*"
                    $CurrentValue=$CurrentSetting.value
                 }
                 If ($VulnID -eq "V-94645")
                 {
                    $CurrentSetting = $vm
                    $CurrentValue = $CurrentSetting.extensiondata.config.MigrateEncryption
                    If ($currentvalue -eq "Opportunistic" -or $currentvalue -eq "Required")
                    {
                        $CorrectlySet= "Not A Finding"
                    }
                 }
                 If ($VulnID -eq "V-94651")
                 {
                    $CurrentSetting = $vm
                    $CurrentValue = $CurrentSetting.extensiondata.config.MigrateEncryption
                    If ($currentvalue -eq "Opportunistic" -or $currentvalue -eq "Required")
                    {
                        $CorrectlySet= "Not A Finding"
                    }
                    Else
                    {
                        $CorrectlySet= "Open"
                    }
                 }
            }



			# Harvest all the information we need for the $CurrentCheck for the $CurrentVM, prepare $Row with the information
			$Row.VM_Hostname=$vm
			$Row.VulnID=$VulnID
			$Row.STIGID=$STIGID 
            $Row.RuleTitle=$RuleTitle			
			$Row.Severity=$Severity
			$Row.Required_Hardening_Setting_Name=$RequiredHardeningSettingName
			$Row.Required_Hardened_Value=$RequiredHardenedValue
			$Row.Current_Value=$CurrentValue
			$Row.Correctly_Set=$CorrectlySet
            $Row.Notes=$Notes

			$csvfileBIG += $Row	
    }		
}	

$csvfileBIG | Export-Csv -NoTypeInformation -force "input_output\6.Results.$Now.csv"


Exit