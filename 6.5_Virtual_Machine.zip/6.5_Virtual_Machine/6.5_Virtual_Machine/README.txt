1. This script requires PowerCLI. Open PowerCLI and navigate to the location of the script. Run the script - you don't need any added parameters to use the script.
2. You only need to configure the file called "1.InputConfigFile.txt" located in the "input_output" folder.
2.A. Make sure the second line of the text file contains the name of the vCenter.
2.B. Make sure the names of the VMs begins on line 4 - avoid having blank lines at the end of the file. (Use display names - see #6)
3. You will need to have the login and password with an account on the vCenter (check Keepass - for IA use)
4. Invalid machine names will be in the document called "4.Output_Invalid_System_Names_xxxxxx.txt" - xxxx will be the vCenter name
5. Valid machine names will be in the document called "3.Output_Valid_System_Names_xxxxxx.txt" -xxxx will be the vCenter name
6. A list of all valid machine names will be the document called "5.Output_All_System_Names_xxxxxx.csv" - xxxx will be the vCenter name
7. Documents that have labels that begin with 3,4, or 5 get written over each time you run the script.
8. Results will be placed in documents appended with the time the script was run.
9. Your welcome.